package ar.edu.cecntro8.desarrollo.proyetoRestaurante.proyectoRestaurante;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoRestauranteApplicationTests {

	@Test
	void contextLoads() {
	}

}
