document.addEventListener("DOMContentLoaded", () => {
    fetchClientes();
});

function fetchClientes() {
    fetch('http://localhost:8080/api/clientes')  
        .then(response => response.json())
        .then(data => {
            const clientesBody = document.getElementById('clientes-body');
            clientesBody.innerHTML = ''; 

            data.forEach(cliente => {
                const row = document.createElement('tr');

                
                row.innerHTML = `
                    <td>${cliente.idcliente}</td>
                    <td>${cliente.nombre}</td>
                    <td>${cliente.apellido}</td>
                    <td>${cliente.telefono}</td>
                    <td>${cliente.direccion}</td>
                    <td>${cliente.pedidos.nombre}</td>`;

                
                clientesBody.appendChild(row);
            });
        })
        .catch(error => {
            console.error('Error al obtener los clientes:', error);
        });
}


