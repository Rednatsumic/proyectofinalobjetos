package ar.edu.cecntro8.desarrollo.proyetoRestaurante.proyectoRestaurante.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import ar.edu.cecntro8.desarrollo.proyetoRestaurante.proyectoRestaurante.model.Cliente;
import ar.edu.cecntro8.desarrollo.proyetoRestaurante.proyectoRestaurante.repository.ClienteRepository;


@RestController
@RequestMapping("/api/clientes")
public class ClienteController {

    @Autowired
    private ClienteRepository clienteRepository;

    @PostMapping
    public ResponseEntity<Cliente> crearCliente(@RequestBody Cliente cliente) {
        return ResponseEntity.ok(clienteRepository.save(cliente));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Cliente> obtenerCliente(@PathVariable Long id) {
        return clienteRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/editar/{id}")
    public String actualizarUnCliente(@PathVariable Long id, @RequestBody Cliente cliente){
        
        Cliente clienteBuscado = clienteRepository.findById(id).get();
        clienteBuscado.setNombre(cliente.getNombre());
        clienteBuscado.setApellido(cliente.getApellido());
        clienteBuscado.setTelefono(cliente.getTelefono());
        clienteBuscado.setDireccion(cliente.getDireccion());

        clienteRepository.save(clienteBuscado);

        return "Datos de cliente actualizado correctamente";


    }


    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarCliente(@PathVariable Long id) {
        clienteRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
