package ar.edu.cecntro8.desarrollo.proyetoRestaurante.proyectoRestaurante.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import ar.edu.cecntro8.desarrollo.proyetoRestaurante.proyectoRestaurante.model.Pedido;
import ar.edu.cecntro8.desarrollo.proyetoRestaurante.proyectoRestaurante.repository.PedidoRepository;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/pedidos")
public class PedidoController {

    @Autowired
    private PedidoRepository pedidoRepository;

    @PostMapping("/crear")
    public ResponseEntity<Pedido> crearPedido(@RequestBody Pedido pedido) {
        return ResponseEntity.ok(pedidoRepository.save(pedido));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Pedido> obtenerPedido(@PathVariable Long id) {
        return pedidoRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/editar/{id}")
    public ResponseEntity<Pedido> actualizarPedido(@PathVariable Long id,
            @RequestParam(required = false) LocalDate fecha,
            @RequestParam(required = false) BigDecimal total) {

        Pedido pedidoActualizado = pedidoRepository.findById(id)
                .map(p -> {
                    if (fecha != null) p.setFecha(fecha);
                    if (total != null) p.setTotal(total);
                    return pedidoRepository.save(p);
                }).orElseThrow(() -> new RuntimeException("Pedido no encontrado"));

        return ResponseEntity.ok(pedidoActualizado);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarPedido(@PathVariable Long id) {
        pedidoRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}