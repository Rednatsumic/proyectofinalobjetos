package ar.edu.cecntro8.desarrollo.proyetoRestaurante.proyectoRestaurante.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ar.edu.cecntro8.desarrollo.proyetoRestaurante.proyectoRestaurante.model.Pedido;
import ar.edu.cecntro8.desarrollo.proyetoRestaurante.proyectoRestaurante.repository.PedidoRepository;




@RestController
@RequestMapping("/api/pedidos")
public class PedidoController {

    @Autowired
    private PedidoRepository pedidoRepository;

    // **Crear un pedido**
    @PostMapping("/crear")
    public ResponseEntity<Pedido> crearPedido(@RequestBody Pedido pedido) {
        return ResponseEntity.ok(pedidoRepository.save(pedido));
    }

    // **Obtener un pedido por ID**
    @GetMapping("/{id}")
    public ResponseEntity<Pedido> obtenerPedido(@PathVariable Long id) {
        return pedidoRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // **Actualizar un pedido**
    @PutMapping("/editar/{id}")
    public ResponseEntity<String> actualizarUnPedido(@PathVariable("id") Long idPedido, @RequestBody Pedido pedido) {
        // Verificar si el pedido existe
        Pedido pedidoBuscado = pedidoRepository.findById(idPedido)
                .orElseThrow(() -> new RuntimeException("Pedido no encontrado con ID: " + idPedido));

        // Actualizar los campos del pedido
        pedidoBuscado.setPedido(pedido.getPedido());
        pedidoBuscado.setFecha(pedido.getFecha());
        pedidoBuscado.setTotal(pedido.getTotal());

        // Guardar los cambios
        pedidoRepository.save(pedidoBuscado);

        return ResponseEntity.ok("Datos del pedido actualizado correctamente");
    }

    // **Eliminar un pedido**
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarPedido(@PathVariable Long id) {
        if (!pedidoRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        pedidoRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}