package ar.edu.cecntro8.desarrollo.proyetoRestaurante.proyectoRestaurante.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import ar.edu.cecntro8.desarrollo.proyetoRestaurante.proyectoRestaurante.model.Pedido;

@Repository
public interface PedidoRepository extends JpaRepository<Pedido, Long> {

}