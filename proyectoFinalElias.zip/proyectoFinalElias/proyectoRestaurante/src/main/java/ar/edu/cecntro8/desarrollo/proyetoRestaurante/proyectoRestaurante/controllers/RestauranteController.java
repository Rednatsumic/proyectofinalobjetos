package ar.edu.cecntro8.desarrollo.proyetoRestaurante.proyectoRestaurante.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import ar.edu.cecntro8.desarrollo.proyetoRestaurante.proyectoRestaurante.repository.ClienteRepository;

@RestController
@RequestMapping("/api")
public class Controlador {

    @Autowired
    private ClienteRepository clienteRepository;
public class RestauranteController {
    
}
