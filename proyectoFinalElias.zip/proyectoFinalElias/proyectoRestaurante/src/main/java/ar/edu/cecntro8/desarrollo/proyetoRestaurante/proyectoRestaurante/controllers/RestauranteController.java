package ar.edu.cecntro8.desarrollo.proyetoRestaurante.proyectoRestaurante.controllers;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import ar.edu.cecntro8.desarrollo.proyetoRestaurante.proyectoRestaurante.model.Restaurante;
import ar.edu.cecntro8.desarrollo.proyetoRestaurante.proyectoRestaurante.repository.RestauranteRepository;



@RestController
@RequestMapping("/api/restaurantes")
public class RestauranteController {

    @Autowired
    private RestauranteRepository restauranteRepository;

    // **Crear un nuevo restaurante**
    @PostMapping("/crear")
    public ResponseEntity<Restaurante> crearRestaurante(@RequestBody Restaurante restaurante) {
        return ResponseEntity.ok(restauranteRepository.save(restaurante));
    }

    // **Obtener un restaurante por ID**
    @GetMapping("/{id}")
    public ResponseEntity<Restaurante> obtenerRestaurante(@PathVariable Long id) {
        return restauranteRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

  @PutMapping("/editar/{id}")
public ResponseEntity<String> actualizarRestaurante(@PathVariable("id") Long idRestaurante, @RequestBody Restaurante restaurante) {
    // Verificar si el restaurante existe
    Optional<Restaurante> restauranteBuscadoOpt = restauranteRepository.findById(idRestaurante);
    
    if (!restauranteBuscadoOpt.isPresent()) {
        // Si no se encuentra el restaurante, devolver una respuesta 404 Not Found
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                             .body("Restaurante no encontrado con ID: " + idRestaurante);
    }

    // Obtener el restaurante de la Optional
    Restaurante restauranteBuscado = restauranteBuscadoOpt.get();

    // Actualizar los campos del restaurante
    if (restaurante.getNombre() != null && !restaurante.getNombre().isEmpty()) {
        restauranteBuscado.setNombre(restaurante.getNombre());
    }
    if (restaurante.getDireccion() != null && !restaurante.getDireccion().isEmpty()) {
        restauranteBuscado.setDireccion(restaurante.getDireccion());
    }
    if (restaurante.getTelefono() != null && !restaurante.getTelefono().isEmpty()) {
        restauranteBuscado.setTelefono(restaurante.getTelefono());
    }

    // Guardar los cambios
    restauranteRepository.save(restauranteBuscado);

    return ResponseEntity.ok("Datos del restaurante actualizados correctamente");
}

    // **Eliminar un restaurante**
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarRestaurante(@PathVariable Long id) {
        restauranteRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}