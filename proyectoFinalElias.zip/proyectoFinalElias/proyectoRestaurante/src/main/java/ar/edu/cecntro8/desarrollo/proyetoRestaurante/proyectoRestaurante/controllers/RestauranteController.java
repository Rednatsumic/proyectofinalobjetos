package ar.edu.cecntro8.desarrollo.proyetoRestaurante.proyectoRestaurante.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import ar.edu.cecntro8.desarrollo.proyetoRestaurante.proyectoRestaurante.model.Restaurante;
import ar.edu.cecntro8.desarrollo.proyetoRestaurante.proyectoRestaurante.repository.RestauranteRepository;

import java.util.List;

@RestController
@RequestMapping("/api/restaurantes")
public class RestauranteController {

    @Autowired
    private RestauranteRepository restauranteRepository;

    @PostMapping("/crear")
    public ResponseEntity<Restaurante> crearRestaurante(@RequestBody Restaurante restaurante) {
        return ResponseEntity.ok(restauranteRepository.save(restaurante));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Restaurante> obtenerRestaurante(@PathVariable Long id) {
        return restauranteRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/editar/{id}")
    public ResponseEntity<Restaurante> actualizarRestaurante(@PathVariable Long id,
            @RequestParam(required = false) String nombre,
            @RequestParam(required = false) String direccion,
            @RequestParam(required = false) String telefono) {

        Restaurante restauranteActualizado = restauranteRepository.findById(id)
                .map(r -> {
                    if (nombre != null && !nombre.isEmpty()) r.setNombre(nombre);
                    if (direccion != null && !direccion.isEmpty()) r.setDireccion(direccion);
                    if (telefono != null && !telefono.isEmpty()) r.setTelefono(telefono);
                    return restauranteRepository.save(r);
                }).orElseThrow(() -> new RuntimeException("Restaurante no encontrado"));

        return ResponseEntity.ok(restauranteActualizado);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarRestaurante(@PathVariable Long id) {
        restauranteRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}