package ar.edu.cecntro8.desarrollo.proyetoRestaurante.proyectoRestaurante.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import ar.edu.cecntro8.desarrollo.proyetoRestaurante.proyectoRestaurante.model.Cliente;
import ar.edu.cecntro8.desarrollo.proyetoRestaurante.proyectoRestaurante.repositories.ClienteRepository;

@RestController
@RequestMapping("/api/cliente")
public class ClienteController {

    @Autowired
    private ClienteRepository clienteRepository;

    @GetMapping("/traer")
    public ResponseEntity<List<Cliente>> traerPersonas() {
        List<Cliente> clientes = clienteRepository.findAll();
        return ResponseEntity.ok(clientes);
    }

    @PostMapping("/crear")
    public ResponseEntity<Cliente> createPersona(@RequestBody Cliente cliente) {
        return ResponseEntity.ok(clienteRepository.save(cliente));
    }

    @GetMapping("/traer/{id}")
    public ResponseEntity<Cliente> traerUnaPersona(@PathVariable Long id) {
        Cliente cliente = clienteRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Cliente no encontrado"));
        return ResponseEntity.ok(cliente);
    }

    @DeleteMapping("/borrar/{id}")
    public ResponseEntity<Void> borrarUnaPersona(@PathVariable Long id) {
        clienteRepository.deleteById(id);
        return ResponseEntity.ok().build();
    }

    @PutMapping("/actualizar/{id}")
    public ResponseEntity<Cliente> actualizarUnaPersona(@PathVariable Long id, @RequestBody Cliente cliente) {
        Cliente existingCliente = clienteRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Cliente no encontrado"));
        
        // Aquí puedes actualizar los campos del cliente según sea necesario
        
        return ResponseEntity.ok(clienteRepository.save(existingCliente));
    }
}
