package ar.edu.cecntro8.desarrollo.proyetoRestaurante.proyectoRestaurante.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import ar.edu.cecntro8.desarrollo.proyetoRestaurante.proyectoRestaurante.model.Pedido;

public interface PedidoRepository extends JpaRepository<Pedido, Long> {
}
