package ar.edu.cecntro8.desarrollo.proyetoRestaurante.proyectoRestaurante.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import ar.edu.cecntro8.desarrollo.proyetoRestaurante.proyectoRestaurante.model.Restaurante;
import ar.edu.cecntro8.desarrollo.proyetoRestaurante.proyectoRestaurante.repositories.RestauranteRepository;


    @RestController
@RequestMapping("/api/restaurante")

public class RestauranteController {
    @Autowired
    private RestauranteRepository restauranteRepository;

    @GetMapping("/traer")
    public ResponseEntity<List<Restaurante>> traerPersonas() {
        List<Restaurante> restaurantes = restauranteRepository.findAll();
        return ResponseEntity.ok(restaurantes);
    }

    @PostMapping("/crear")
    public ResponseEntity<Restaurante> createPersona(@RequestBody Restaurante restaurante) {
        return ResponseEntity.ok(restauranteRepository.save(restaurante));
    }

    @GetMapping("/traer/{id}")
    public ResponseEntity<Restaurante> traerUnaPersona(@PathVariable Long id) {
        Restaurante restaurante = restauranteRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Restaurante no encontrado"));
        return ResponseEntity.ok(restaurante);
    }

    @DeleteMapping("/borrar/{id}")
    public ResponseEntity<Void> borrarUnaPersona(@PathVariable Long id) {
        restauranteRepository.deleteById(id);
        return ResponseEntity.ok().build();
    }

    @PutMapping("/actualizar/{id}")
    public ResponseEntity<Restaurante> actualizarUnaPersona(@PathVariable Long id, @RequestBody Restaurante restaurante) {
        Restaurante existingRestaurante = restauranteRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Restaurante no encontrado"));
        
        // Aquí puedes actualizar los campos del restaurante según sea necesario
        
        return ResponseEntity.ok(restauranteRepository.save(existingRestaurante));
    }
}

