package ar.edu.cecntro8.desarrollo.proyetoRestaurante.proyectoRestaurante.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import ar.edu.cecntro8.desarrollo.proyetoRestaurante.proyectoRestaurante.model.Pedido;
import ar.edu.cecntro8.desarrollo.proyetoRestaurante.proyectoRestaurante.repositories.PedidoRepository;


    @RestController
@RequestMapping("/api/pedido")
public class PedidoController {

    @Autowired
    private PedidoRepository pedidoRepository;

    @GetMapping("/traer")
    public ResponseEntity<List<Pedido>> traerPersonas() {
        List<Pedido> pedidos = pedidoRepository.findAll();
        return ResponseEntity.ok(pedidos);
    }

    @PostMapping("/crear")
    public ResponseEntity<Pedido> createPersona(@RequestBody Pedido pedido) {
        return ResponseEntity.ok(pedidoRepository.save(pedido));
    }

    @GetMapping("/traer/{id}")
    public ResponseEntity<Pedido> traerUnaPersona(@PathVariable Long id) {
        Pedido pedido = pedidoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Pedido no encontrado"));
        return ResponseEntity.ok(pedido);
    }

    @DeleteMapping("/borrar/{id}")
    public ResponseEntity<Void> borrarUnaPersona(@PathVariable Long id) {
        pedidoRepository.deleteById(id);
        return ResponseEntity.ok().build();
    }

    @PutMapping("/actualizar/{id}")
    public ResponseEntity<Pedido> actualizarUnaPersona(@PathVariable Long id, @RequestBody Pedido pedido) {
        Pedido existingPedido = pedidoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Pedido no encontrado"));
        
        // Aquí puedes actualizar los campos del pedido según sea necesario
        
        return ResponseEntity.ok(pedidoRepository.save(existingPedido));
    }
}

