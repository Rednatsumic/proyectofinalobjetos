package ar.edu.entro8.desarrollo.proyectoRestaurante2.restaurante.controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import ar.edu.entro8.desarrollo.proyectoRestaurante2.restaurante.model.Cliente;
import ar.edu.entro8.desarrollo.proyectoRestaurante2.restaurante.repository.ClienteRepository;

@RestController
@RequestMapping("/api/cliente")
public class ClienteController {

    @Autowired
    private ClienteRepository clienteRepository;

    // Método para obtener todos los clientes
    @GetMapping("/todos")
    public List<Cliente> obtenerTodosLosClientes() {
        return clienteRepository.findAll();
    }

    // Método para crear un cliente
    @PostMapping("/crear")
    public Cliente crearCliente(@RequestBody Cliente cliente) {
        return clienteRepository.save(cliente);
    }

    // Método para buscar un cliente por su ID
    @GetMapping("/buscarPorId/{id}")
    public Cliente buscarClientePorId(@PathVariable Long id) {
        return clienteRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Cliente no encontrado"));
    }

    // Método para actualizar un cliente por su ID
    @PutMapping("/actualizar/{id}")
    public Cliente actualizarCliente(@PathVariable Long id, @RequestBody Cliente clienteActualizado) {
        // Buscar cliente existente
        Cliente existingCliente = clienteRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Cliente no encontrado"));

        // Actualizar los campos con los datos proporcionados
        existingCliente.setNombre(clienteActualizado.getNombre());
        existingCliente.setApellido(clienteActualizado.getApellido());
        existingCliente.setEmail(clienteActualizado.getEmail());

        // Guardar y devolver el cliente actualizado
        return clienteRepository.save(existingCliente);
    }

    // Método para eliminar un cliente por su ID
    @DeleteMapping("/eliminar/{id}")
    public void eliminarCliente(@PathVariable Long id) {
        clienteRepository.deleteById(id);
    }
}