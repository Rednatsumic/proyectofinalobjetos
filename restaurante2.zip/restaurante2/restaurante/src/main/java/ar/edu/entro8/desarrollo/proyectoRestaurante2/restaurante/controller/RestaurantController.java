package ar.edu.entro8.desarrollo.proyectoRestaurante2.restaurante.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import ar.edu.entro8.desarrollo.proyectoRestaurante2.restaurante.model.Restaurante;
import ar.edu.entro8.desarrollo.proyectoRestaurante2.restaurante.repository.RestauranteRepository;

@RestController
@RequestMapping("/api/restaurante")
public class RestaurantController {

    @Autowired
    private RestauranteRepository restaurantRepository;

    @GetMapping("/restaurantes")
    public List<Restaurante> obtenerRestaurantes() {
        return restaurantRepository.findAll();
    }

    @PostMapping("/crear")
    public Restaurante crearRestaurant(@RequestBody Restaurante restaurant) {
        return restaurantRepository.save(restaurant);
    }

    @GetMapping("/restaurantes/{id}")
    public Restaurante obtenerRestaurant(@PathVariable Long id) {
        return restaurantRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Restaurant no encontrado"));
    }

    @PutMapping("/actualizar/{id}")
    public Restaurante actualizarRestaurant(@PathVariable Long id, @RequestBody Restaurante restaurant) {
        Restaurante existingRestaurant = restaurantRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Restaurant no encontrado"));
        
        existingRestaurant.setNombre(restaurant.getNombre());
        existingRestaurant.setTelefono(restaurant.getTelefono());
        existingRestaurant.setDireccion(restaurant.getDireccion());

        return restaurantRepository.save(existingRestaurant);
    }

    @DeleteMapping("/eliminar/{id}")
    public void eliminarRestaurant(@PathVariable Long id) {
        restaurantRepository.deleteById(id);
    }
}