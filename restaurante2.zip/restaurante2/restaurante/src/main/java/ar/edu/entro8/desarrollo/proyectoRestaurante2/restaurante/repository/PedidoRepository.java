package ar.edu.entro8.desarrollo.proyectoRestaurante2.restaurante.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import ar.edu.entro8.desarrollo.proyectoRestaurante2.restaurante.model.Pedido;

public interface PedidoRepository extends JpaRepository<Pedido, Long> {
}

