package ar.edu.entro8.desarrollo.proyectoRestaurante2.restaurante.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import ar.edu.entro8.desarrollo.proyectoRestaurante2.restaurante.model.Cliente;

public interface ClienteRepository extends JpaRepository<Cliente, Long> {
}