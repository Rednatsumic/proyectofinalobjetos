package ar.edu.entro8.desarrollo.proyectoRestaurante2.restaurante.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import ar.edu.entro8.desarrollo.proyectoRestaurante2.restaurante.model.Restaurante;

public interface RestauranteRepository extends JpaRepository<Restaurante, Long> {
}
